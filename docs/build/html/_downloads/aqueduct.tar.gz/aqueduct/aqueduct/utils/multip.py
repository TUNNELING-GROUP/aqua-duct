# -*- coding: utf-8 -*-
'''
Created on Feb 3, 2016

@author: tljm
'''


# mulitprocessing helpers
