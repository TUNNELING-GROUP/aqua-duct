# -*- coding: utf-8 -*-
from unittest import TestCase


class TestAuto(TestCase):
    pass
class TestCombineExist(TestCase):
    def test_combine(self):
        self.assertTrue(1==1)
