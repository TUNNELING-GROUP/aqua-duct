# -*- coding: utf-8 -*-
from unittest import TestCase


class TestSmooth(TestCase):
    def test_smooth(self):
        self.fail()
