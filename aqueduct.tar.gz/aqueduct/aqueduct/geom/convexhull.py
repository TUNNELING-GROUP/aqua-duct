'''
Created on Dec 4, 2015

@author: tljm
'''

from aqueduct.geom.convexhull_scipy import ConvexHull

